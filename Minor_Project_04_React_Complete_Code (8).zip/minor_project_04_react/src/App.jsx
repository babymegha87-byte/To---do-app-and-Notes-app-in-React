import { useState } from "react";
import TodoApp from "./components/TodoApp.jsx";
import NotesApp from "./components/NotesApp.jsx";

export default function App() {
  const [activePage, setActivePage] = useState("tasks");

  return (
    <div className="app-shell">
      <header className="topbar">
        <a className="brand" href="#" onClick={(event) => { event.preventDefault(); setActivePage("tasks"); }}>
          <span className="brand-mark">✦</span>
          <span>daylight<span className="brand-dot">.</span></span>
        </a>
        <nav className="main-nav" aria-label="Main navigation">
          <button className={activePage === "tasks" ? "nav-link active" : "nav-link"} onClick={() => setActivePage("tasks")}>
            <span aria-hidden="true">☷</span> Tasks
          </button>
          <button className={activePage === "notes" ? "nav-link active" : "nav-link"} onClick={() => setActivePage("notes")}>
            <span aria-hidden="true">▤</span> Notes
          </button>
        </nav>
        <div className="topbar-label"><span className="status-dot" /> Your personal workspace</div>
      </header>

      <main className="main-content">
        {activePage === "tasks" ? <TodoApp /> : <NotesApp />}
      </main>

      <footer className="footer">
        <span>Made for your everyday ideas.</span>
        <span>React · Local Storage</span>
      </footer>
    </div>
  );
}
