import { useEffect, useMemo, useState } from "react";
import NoteCard from "./NoteCard.jsx";

const STORAGE_KEY = "minor-project-04-notes";
const CATEGORIES = ["Personal", "Study", "Work", "Ideas"];

function readNotes() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? JSON.parse(saved) : [];
  } catch {
    return [];
  }
}

export default function NotesApp() {
  const [notes, setNotes] = useState(readNotes);
  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("All");
  const [showEditor, setShowEditor] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [category, setCategory] = useState("Personal");

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(notes));
  }, [notes]);

  const filteredNotes = useMemo(() => {
    const query = search.trim().toLowerCase();
    return notes.filter((note) => {
      const matchesSearch = `${note.title} ${note.content}`.toLowerCase().includes(query);
      const matchesCategory = categoryFilter === "All" || note.category === categoryFilter;
      return matchesSearch && matchesCategory;
    }).sort((a, b) => b.updatedAt - a.updatedAt);
  }, [notes, search, categoryFilter]);

  function openNewNote() {
    setEditingId(null);
    setTitle("");
    setContent("");
    setCategory("Personal");
    setShowEditor(true);
  }

  function openEditNote(note) {
    setEditingId(note.id);
    setTitle(note.title);
    setContent(note.content);
    setCategory(note.category);
    setShowEditor(true);
  }

  function saveNote(event) {
    event.preventDefault();
    if (!title.trim() && !content.trim()) return;
    const now = Date.now();
    if (editingId) {
      setNotes((current) => current.map((note) => note.id === editingId
        ? { ...note, title: title.trim() || "Untitled note", content: content.trim(), category, updatedAt: now }
        : note));
    } else {
      setNotes((current) => [{ id: crypto.randomUUID ? crypto.randomUUID() : `${now}-${Math.random()}`, title: title.trim() || "Untitled note", content: content.trim(), category, createdAt: now, updatedAt: now }, ...current]);
    }
    setShowEditor(false);
  }

  function deleteNote(id) {
    setNotes((current) => current.filter((note) => note.id !== id));
    if (editingId === id) setShowEditor(false);
  }

  return (
    <section className="page-section notes-page">
      <div className="eyebrow"><span className="eyebrow-line" /> A HOME FOR YOUR THOUGHTS</div>
      <div className="page-heading-row">
        <div><h1>Thoughts worth <span>keeping.</span></h1><p className="subtitle">Collect the little ideas you don't want to lose.</p></div>
        <button className="primary-button new-note-button" onClick={openNewNote}>＋ New note</button>
      </div>

      <div className="notes-overview">
        <div className="note-overview-icon">▤</div>
        <div><strong>{notes.length} {notes.length === 1 ? "note" : "notes"} and counting</strong><p>Your thoughts, neatly in one place.</p></div>
        <div className="overview-decoration">✧</div>
      </div>

      {showEditor && (
        <div className="editor-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setShowEditor(false); }}>
          <form className="note-editor" onSubmit={saveNote} aria-label={editingId ? "Edit note" : "Create note"}>
            <div className="editor-heading"><div><span className="eyebrow">YOUR NOTE</span><h2>{editingId ? "Edit your note" : "A new thought"}</h2></div><button type="button" className="close-button" onClick={() => setShowEditor(false)} aria-label="Close editor">×</button></div>
            <label htmlFor="note-title">Title</label>
            <input id="note-title" value={title} onChange={(event) => setTitle(event.target.value)} placeholder="Give your note a title..." maxLength={100} />
            <label htmlFor="note-category">Category</label>
            <select id="note-category" value={category} onChange={(event) => setCategory(event.target.value)}>{CATEGORIES.map((item) => <option key={item} value={item}>{item}</option>)}</select>
            <label htmlFor="note-content">Your thoughts</label>
            <textarea id="note-content" value={content} onChange={(event) => setContent(event.target.value)} placeholder="Start writing here..." rows={6} maxLength={10000} />
            <div className="editor-actions"><button type="button" className="secondary-button" onClick={() => setShowEditor(false)}>Cancel</button><button type="submit" className="primary-button">{editingId ? "Save changes" : "Save note"}</button></div>
          </form>
        </div>
      )}

      <div className="notes-tools">
        <div className="search-box"><span>⌕</span><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search your notes..." aria-label="Search notes" />{search && <button onClick={() => setSearch("")} aria-label="Clear search">×</button>}</div>
        <label className="category-select-label" htmlFor="category-filter">Category</label>
        <select id="category-filter" className="category-filter" value={categoryFilter} onChange={(event) => setCategoryFilter(event.target.value)}><option>All</option>{CATEGORIES.map((item) => <option key={item}>{item}</option>)}</select>
      </div>

      <div className="notes-grid">
        {filteredNotes.length ? filteredNotes.map((note) => <NoteCard key={note.id} note={note} onEdit={() => openEditNote(note)} onDelete={() => deleteNote(note.id)} />) : (
          <div className="notes-empty"><div className="empty-icon">✧</div><strong>{notes.length ? "Nothing found just yet." : "Your page is still blank."}</strong><p>{notes.length ? "Try a different search or category." : "Create your first note and save an idea for later."}</p>{!notes.length && <button className="primary-button" onClick={openNewNote}>Create your first note ＋</button>}</div>
        )}
      </div>
      <div className="notes-footer"><span>✦ Every good idea starts somewhere.</span><span>Saved automatically</span></div>
    </section>
  );
}
