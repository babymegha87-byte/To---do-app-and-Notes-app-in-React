export default function TodoItem({ task, editing, editText, editDate, onEditText, onEditDate, onToggle, onDelete, onBeginEdit, onSave, onCancel }) {
  const dateLabel = task.dueDate
    ? new Date(`${task.dueDate}T00:00:00`).toLocaleDateString(undefined, { month: "short", day: "numeric" })
    : "";

  return (
    <article className={`task-item ${task.completed ? "is-completed" : ""}`}>
      <button className={`task-checkbox ${task.completed ? "checked" : ""}`} onClick={onToggle} aria-label={task.completed ? "Mark as pending" : "Mark as completed"}>
        {task.completed ? "✓" : ""}
      </button>
      <div className="task-main">
        {editing ? (
          <div className="edit-task-fields">
            <input autoFocus value={editText} maxLength={180} onChange={(event) => onEditText(event.target.value)} aria-label="Edit task title" />
            <input type="date" value={editDate} onChange={(event) => onEditDate(event.target.value)} aria-label="Edit due date" />
          </div>
        ) : (
          <>
            <div className="task-title">{task.title}</div>
            <div className="task-meta">
              <span className={`status-label ${task.completed ? "status-done" : "status-pending"}`}>{task.completed ? "Completed" : "Pending"}</span>
              {dateLabel && <span className="due-date">◷ Due {dateLabel}</span>}
            </div>
          </>
        )}
      </div>
      <div className="task-actions">
        {editing ? <>
          <button className="icon-button save-action" onClick={onSave} aria-label="Save edit" title="Save">✓</button>
          <button className="icon-button" onClick={onCancel} aria-label="Cancel edit" title="Cancel">×</button>
        </> : <>
          <button className="icon-button" onClick={onBeginEdit} aria-label="Edit task" title="Edit">✎</button>
          <button className="icon-button delete-action" onClick={onDelete} aria-label="Delete task" title="Delete">⌫</button>
        </>}
      </div>
    </article>
  );
}
