import { useEffect, useMemo, useState } from "react";
import TodoItem from "./TodoItem.jsx";

const STORAGE_KEY = "minor-project-04-tasks";

function readTasks() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? JSON.parse(saved) : [];
  } catch {
    return [];
  }
}

export default function TodoApp() {
  const [tasks, setTasks] = useState(readTasks);
  const [taskText, setTaskText] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [filter, setFilter] = useState("all");
  const [editingId, setEditingId] = useState(null);
  const [editText, setEditText] = useState("");
  const [editDate, setEditDate] = useState("");

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
  }, [tasks]);

  const completedCount = tasks.filter((task) => task.completed).length;
  const pendingCount = tasks.length - completedCount;
  const progress = tasks.length ? Math.round((completedCount / tasks.length) * 100) : 0;

  const visibleTasks = useMemo(() => {
    if (filter === "completed") return tasks.filter((task) => task.completed);
    if (filter === "pending") return tasks.filter((task) => !task.completed);
    return tasks;
  }, [tasks, filter]);

  function addTask(event) {
    event.preventDefault();
    const title = taskText.trim();
    if (!title) return;
    setTasks((current) => [
      { id: crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`, title, dueDate, completed: false, createdAt: new Date().toISOString() },
      ...current
    ]);
    setTaskText("");
    setDueDate("");
  }

  function toggleTask(id) {
    setTasks((current) => current.map((task) => task.id === id ? { ...task, completed: !task.completed } : task));
  }

  function deleteTask(id) {
    setTasks((current) => current.filter((task) => task.id !== id));
    if (editingId === id) setEditingId(null);
  }

  function beginEdit(task) {
    setEditingId(task.id);
    setEditText(task.title);
    setEditDate(task.dueDate || "");
  }

  function saveEdit(id) {
    const title = editText.trim();
    if (!title) return;
    setTasks((current) => current.map((task) => task.id === id ? { ...task, title, dueDate: editDate } : task));
    setEditingId(null);
  }

  return (
    <section className="page-section">
      <div className="eyebrow"><span className="eyebrow-line" /> YOUR DAY, YOUR WAY</div>
      <div className="page-heading-row">
        <div>
          <h1>Make space for <span>what matters.</span></h1>
          <p className="subtitle">A little progress every day adds up to big things.</p>
        </div>
        <div className="date-pill"><span>◷</span> {new Date().toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" })}</div>
      </div>

      <div className="stats-grid">
        <div className="stat-card stat-total"><span className="stat-icon">▤</span><span className="stat-label">All tasks</span><strong>{tasks.length}</strong><span className="stat-note">Everything on your list</span></div>
        <div className="stat-card stat-pending"><span className="stat-icon">◷</span><span className="stat-label">In progress</span><strong>{pendingCount}</strong><span className="stat-note">One step at a time</span></div>
        <div className="stat-card stat-complete"><span className="stat-icon">✓</span><span className="stat-label">Completed</span><strong>{completedCount}</strong><span className="stat-note">Look how far you've come</span></div>
        <div className="stat-card stat-progress"><span className="stat-icon">↗</span><span className="stat-label">Your progress</span><strong>{progress}<small>%</small></strong><div className="progress-track"><span style={{ width: `${progress}%` }} /></div></div>
      </div>

      <div className="content-panel">
        <div className="panel-heading">
          <div><h2>Today's tasks <span className="count-badge">{tasks.length}</span></h2><p>Keep your priorities close.</p></div>
        </div>
        <form className="task-form" onSubmit={addTask}>
          <label className="sr-only" htmlFor="new-task">Add a task</label>
          <span className="input-plus">＋</span>
          <input id="new-task" value={taskText} onChange={(event) => setTaskText(event.target.value)} placeholder="What needs to get done?" maxLength={180} />
          <label className="sr-only" htmlFor="due-date">Optional due date</label>
          <input id="due-date" className="date-input" type="date" value={dueDate} onChange={(event) => setDueDate(event.target.value)} />
          <button className="primary-button" type="submit">Add task <span>＋</span></button>
        </form>

        <div className="list-toolbar">
          <div className="filter-tabs" aria-label="Filter tasks">
            {[["all", "All tasks"], ["pending", "Pending"], ["completed", "Completed"]].map(([value, label]) => (
              <button key={value} className={filter === value ? "filter-tab selected" : "filter-tab"} onClick={() => setFilter(value)}>{label}</button>
            ))}
          </div>
          <span className="muted-small">{visibleTasks.length} {visibleTasks.length === 1 ? "task" : "tasks"}</span>
        </div>

        <div className="task-list">
          {visibleTasks.length ? visibleTasks.map((task) => (
            <TodoItem key={task.id} task={task} editing={editingId === task.id}
              editText={editText} editDate={editDate}
              onEditText={setEditText} onEditDate={setEditDate}
              onToggle={() => toggleTask(task.id)} onDelete={() => deleteTask(task.id)}
              onBeginEdit={() => beginEdit(task)} onSave={() => saveEdit(task.id)}
              onCancel={() => setEditingId(null)} />
          )) : (
            <div className="empty-state"><div className="empty-icon">✧</div><strong>{filter === "all" ? "A fresh start." : `No ${filter} tasks.`}</strong><p>{filter === "all" ? "Add your first task above and make today count." : "Try another filter or add a new task."}</p></div>
          )}
        </div>
        <div className="panel-bottom"><span><span className="tiny-check">✓</span> Small steps are still progress.</span><span>Saved automatically</span></div>
      </div>
    </section>
  );
}
