const categoryClasses = {
  Personal: "category-personal",
  Study: "category-study",
  Work: "category-work",
  Ideas: "category-ideas"
};

export default function NoteCard({ note, onEdit, onDelete }) {
  const dateLabel = new Date(note.updatedAt).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });

  return (
    <article className={`note-card ${categoryClasses[note.category] || "category-personal"}`}>
      <div className="note-card-top">
        <span className="category-chip">{note.category}</span>
        <div className="note-card-actions">
          <button className="icon-button" onClick={onEdit} title="Edit note" aria-label="Edit note">✎</button>
          <button className="icon-button delete-action" onClick={onDelete} title="Delete note" aria-label="Delete note">⌫</button>
        </div>
      </div>
      <h3>{note.title}</h3>
      <p className="note-preview">{note.content || "No extra details yet."}</p>
      <div className="note-card-bottom"><span>◷ Updated {dateLabel}</span><button onClick={onEdit}>Open note <span>↗</span></button></div>
    </article>
  );
}
