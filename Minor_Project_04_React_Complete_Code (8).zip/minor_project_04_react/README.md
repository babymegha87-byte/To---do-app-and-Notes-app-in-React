# Minor Project 04 — To-Do App + Notes App in React

A responsive two-in-one productivity application built for the Web Development Week 04 minor project.

## Features

### TaskFlow (To-Do App)
- Add, edit and delete tasks
- Mark tasks as completed or pending
- Filter all, pending and completed tasks
- Optional due dates
- Local Storage persistence
- Task counts and responsive layout

### NoteSpace (Notes App)
- Create, edit and delete notes
- Search note titles and content
- Categorize notes
- Show created/updated timestamps
- Local Storage persistence
- Responsive card layout

## Technologies Used
- React.js and JSX
- JavaScript ES6+
- CSS3
- Vite
- React Hooks: `useState`, `useEffect`
- Browser Local Storage

## Setup Instructions

1. Install Node.js (LTS) from https://nodejs.org/
2. Extract this project ZIP.
3. Open the extracted `minor_project_04_react` folder in VS Code.
4. Open Terminal in VS Code and run:

   ```bash
   npm install
   npm run dev
   ```

5. Open the local URL printed by Vite (usually `http://localhost:5173`).

## Build for production

```bash
npm run build
npm run preview
```

## Project Structure

```text
minor_project_04_react/
├── index.html
├── package.json
├── README.md
└── src/
    ├── main.jsx
    ├── App.jsx
    ├── styles.css
    └── components/
        ├── TodoApp.jsx
        ├── TodoItem.jsx
        ├── NotesApp.jsx
        └── NoteCard.jsx
```

## Concepts Demonstrated
- Functional components and JSX
- Props and reusable components
- State with `useState`
- Side effects with `useEffect`
- Event handling and conditional rendering
- List rendering with `.map()`
- Array methods including `.filter()` and `.find()`
- Arrow functions, template literals, destructuring, spread operator, `let` and `const`

## Notes
Data is stored in the browser's Local Storage for the same browser and origin. Clearing browser site data will remove locally saved tasks and notes.
